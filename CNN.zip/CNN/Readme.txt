## Dependencies

* python 3
* PyTorch 1.6
* tqdm
* imageio
* scikit-image
* numpy
* matplotlib
* readline

## Datasets

* GOPRO: [link](https://paperswithcode.com/dataset/gopro)